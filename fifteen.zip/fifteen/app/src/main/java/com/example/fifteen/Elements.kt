package com.example.fifteen

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Button
import androidx.compose.material.ButtonDefaults
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

fun win(list: List<String>, uWin: MutableState<Boolean>) {
    val listWin =
        listOf(
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "0"
        )
    list.forEachIndexed { index, element ->
        if(element == listWin[index]) uWin.value = true
        else {
            uWin.value = false
            return
        }
    }
}

fun left(
    list: MutableList<String>,
    uWin: MutableState<Boolean>,
    counter: MutableState<Int>
): MutableList<String> {
    val oldRight = list.indexOf(element = "0")
    if (
        list[oldRight] != list[0] &&
        list[oldRight] != list[4] &&
        list[oldRight] != list[8] &&
        list[oldRight] != list[12]
    ) {
        val oldLeft = list[oldRight - 1]
        list[oldRight] = oldLeft
        list[oldRight - 1] = "0"
        counter.value +=1
    }
    win(list, uWin)
    return list
}

fun right(list: MutableList<String>, uWin: MutableState<Boolean>, counter: MutableState<Int>): MutableList<String> {
    val oldLeft = list.indexOf(element = "0")
    if (
        list[oldLeft] != list[15] &&
        list[oldLeft] != list[11] &&
        list[oldLeft] != list[7] &&
        list[oldLeft] != list[3]
    ) {
        val oldRight = list[oldLeft + 1]
        list[oldLeft] = oldRight
        list[oldLeft + 1] = "0"
        counter.value +=1
    }
    win(list, uWin)
    return list
}

fun up(list: MutableList<String>, uWin: MutableState<Boolean>, counter: MutableState<Int>): MutableList<String> {
    val oldDown = list.indexOf(element = "0")
    if (
        list[oldDown] != list[3] &&
        list[oldDown] != list[2] &&
        list[oldDown] != list[1] &&
        list[oldDown] != list[0]
    ) {
        val oldUp = list[oldDown - 4]
        list[oldDown] = oldUp
        list[oldDown - 4] = "0"
        counter.value +=1
    }
    win(list, uWin)
    return list
}

fun down(list: MutableList<String>, uWin: MutableState<Boolean>, counter: MutableState<Int>): MutableList<String> {
    val oldUp = list.indexOf(element = "0")
    if (
        list[oldUp] != list[15] &&
        list[oldUp] != list[14] &&
        list[oldUp] != list[13] &&
        list[oldUp] != list[12]
    ) {
        val oldDown = list[oldUp + 4]
        list[oldUp] = oldDown
        list[oldUp + 4] = "0"
        counter.value +=1
    }
    win(list, uWin)
    return list
}

fun random(list: MutableList<String>,counter: MutableState<Int>): MutableList<String> {
    list.shuffle()
    counter.value = 0
    return list
}

@Composable
fun ButtonField(list: List<String>, index: Int) {
    Button(
        onClick = { /*TODO*/ },
        modifier = Modifier.padding(10.dp),
        colors =
        if (list[index] == "0") ButtonDefaults.buttonColors(
            backgroundColor = Color.Black,
            contentColor = Color.Black
        )
        else ButtonDefaults.buttonColors(
            backgroundColor = Color.White,
            contentColor = Color.Black
        ),
        border = BorderStroke(3.dp, Color.Black)
    ) { Text(text = list[index]) }

}