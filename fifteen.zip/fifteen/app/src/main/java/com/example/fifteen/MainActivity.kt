package com.example.fifteen

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CornerSize
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.consumeAllChanges
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.fifteen.ui.theme.FifteenTheme
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FifteenTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Black
                ) {
                    PlayingField()
                }
            }
        }
    }
}

@Composable
fun PlayingField() {
    val list = remember {
        mutableStateListOf(
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
        )
    }
    val openDialog = remember { mutableStateOf(false) }
    val meaningDialog = remember { mutableStateOf(false) }
    var direction by remember { mutableStateOf(-1) }
    val uWin = remember { mutableStateOf(false) }
    val counter = remember { mutableStateOf(0) }
    Column(modifier = Modifier.pointerInput(Unit) {
        detectDragGestures(
            onDrag = { change, dragAmount ->
                change.consumeAllChanges()
                val (x, y) = dragAmount
                if (abs(x) > abs(y))
                {
                    when {
                        x > 0 -> direction = 0
                        x < 0 -> direction = 1
                    }
                } else
                {
                    when {
                        y > 0 -> direction = 2
                        y < 0 -> direction = 3
                    }

                }
            },
            onDragEnd = {
                when (direction)
                {
                    0 -> right(list, uWin,counter)
                    1 -> left(list, uWin,counter)
                    2 -> down(list, uWin,counter)
                    3 -> up(list, uWin,counter)
                }
            }
        )
    }) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            ButtonField(list, 0)
            ButtonField(list, 1)
            ButtonField(list, 2)
            ButtonField(list, 3)
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            ButtonField(list, 4)
            ButtonField(list, 5)
            ButtonField(list, 6)
            ButtonField(list, 7)
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            ButtonField(list, 8)
            ButtonField(list, 9)
            ButtonField(list, 10)
            ButtonField(list, 11)
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            ButtonField(list, 12)
            ButtonField(list, 13)
            ButtonField(list, 14)
            ButtonField(list, 15)
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            Text(text = "вы сделали : ${counter.value} перемещений", color = Color.White)
        }
        Scaffold(
            backgroundColor = Color.Black,
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { meaningDialog.value = true },
                    backgroundColor = colorResource(id = R.color.purple_500),
                ) {
                    Text("?")
                }
            },
            floatingActionButtonPosition = FabPosition.End,
            bottomBar = {
                BottomAppBar(
                    cutoutShape = MaterialTheme.shapes.small.copy(
                        CornerSize(percent = 50)
                    ),
                    backgroundColor = Color.Black
                ){
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Button(
                                onClick = { random(list,counter) },
                                modifier = Modifier.padding(10.dp),
                                colors =  ButtonDefaults.buttonColors
                                    (backgroundColor = colorResource(id = R.color.purple_500)),
                                border = BorderStroke(3.dp, Color.White)
                            ) {
                                Text(text = stringResource(id = R.string.new_game))
                            }
                            Button(
                                onClick = { openDialog.value = true },
                                modifier = Modifier.padding(10.dp),
                                enabled = uWin.value,
                                colors =  ButtonDefaults.buttonColors
                                    (backgroundColor = colorResource(id = R.color.purple_500)),
                                border = BorderStroke(3.dp, Color.White)

                            ) {
                                Text(stringResource(id = R.string.end))
                            }
                            if (openDialog.value) {
                                AlertDialog(
                                    onDismissRequest = {
                                        openDialog.value = true
                                    },
                                    title = {
                                        Text(text = "ты прошел игру за ${counter.value} свайпов") },
                                    text = { Text("Да ты победил") },
                                    buttons = {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.End
                                        ){
                                            Button(
                                                onClick = { openDialog.value = false }
                                            ) {
                                                Text("OK")
                                            }
                                        }
                                    }
                                )
                            }
                            if (meaningDialog.value) {
                                AlertDialog(
                                    onDismissRequest = {
                                        meaningDialog.value = true
                                    },
                                    title = { Text(text = "Смысл игры") },
                                    text = {
                                        Text(stringResource(id = R.string.regulations))},
                                    buttons = {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.End
                                        ){
                                            Button(
                                                onClick = { meaningDialog.value = false }
                                            ) {
                                                Text("OK")
                                            }
                                        }
                                    }
                                )
                            }
                        }
                    } }
            })
        {
        }
    }
}